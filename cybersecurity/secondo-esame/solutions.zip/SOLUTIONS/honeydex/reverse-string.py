str = "}629798_ekoPWOOOOOLS_ereh_yllaniF{ZTIRPS";

print(str[::-1]);
